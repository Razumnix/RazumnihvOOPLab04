﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4OOP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExecute_Click(object sender, EventArgs e)
        {
            string result = "";

            // Виведення початкового одномірного масиву
            double[] arr = { 5.5, -3.2, 7.8, 10.0, 8.0, -2.5, 6.3, 9.9 };
            result += "Початковий одномірний масив:" + Environment.NewLine;
            foreach (double num in arr)
            {
                result += num + "\t";
            }
            result += Environment.NewLine + Environment.NewLine;


            //1: Обчислення для одномірного масиву
            // Задаємо число С для порівняння
            double C = 7.0;

            // a) Кількість елементів, що менші за число C
            int countLessThanC = 0;
            foreach (double num in arr)
            {
                if (num < C)
                    countLessThanC++;
            }
            result += "Кількість елементів, що менші за " + C + ": " + countLessThanC + Environment.NewLine;

            // b) Сума цілих частин елементів після останнього від’ємного
            int lastNegativeIndex = -1;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] < 0)
                    lastNegativeIndex = i;
            }
            int sumIntegerParts = 0;
            if (lastNegativeIndex != -1 && lastNegativeIndex < arr.Length - 1)
            {
                for (int i = lastNegativeIndex + 1; i < arr.Length; i++)
                {
                    
                    sumIntegerParts += (int)arr[i];
                }
            }
            result += "Сума цілих частин після останнього від’ємного: " + sumIntegerParts + Environment.NewLine;

            // Спочатку – елементи, що відрізняються від максимального не більше, ніж на 20%
            double max = arr[0];
            foreach (double num in arr)
            {
                if (num > max)
                    max = num;
            }
            result += "Максимальний елемент: " + max + Environment.NewLine;

            List<double> group1 = new List<double>(); // елементи, що ближчі до max
            List<double> group2 = new List<double>(); // інші елементи

            foreach (double num in arr)
            {
                if ((max - num) <= (0.2 * max))
                    group1.Add(num);
                else
                    group2.Add(num);
            }
            double[] transformedArray = group1.Concat(group2).ToArray();
            result += "Перетворений масив:" + Environment.NewLine;
            foreach (double num in transformedArray)
            {
                result += num + "\t";
            }
            result += Environment.NewLine + Environment.NewLine;


            //2: Обчислення для двовимірного масиву

            result += "Двовимірний масив:" + Environment.NewLine;
            int[,] twoDimArray = new int[,]
            {
                { 1, 2, 3, 4 },
                { 5, 6, 7, 8 },
                { 9, 10, 11, 12 }
            };

            int rows = twoDimArray.GetLength(0);
            int cols = twoDimArray.GetLength(1);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    result += twoDimArray[i, j] + "\t";
                }
                result += Environment.NewLine;
            }

            // Виведення прикладів елементів із двовимірного масиву:
            if (cols > 2)
                result += Environment.NewLine + "Елемент [0,2] (3-й стовпець): " + twoDimArray[0, 2] + Environment.NewLine;
            if (rows > 1 && cols > 1)
                result += "Елемент [1,1]: " + twoDimArray[1, 1] + Environment.NewLine;

            // Остаточний вивід у TextBox
            textBoxOutput.Text = result;
        }
    }




}
